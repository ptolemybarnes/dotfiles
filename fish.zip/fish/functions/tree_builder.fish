function tree_builder
  set entrypoint $argv
  set entrypoint_dir (dirname $entrypoint)
  ruby --debug -X $entrypoint_dir /Users/ptolemy/deck/tree-builder/main.rb $entrypoint
end
