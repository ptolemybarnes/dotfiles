source ~/.config/fish/aliases.fish

set -x EDITOR vim

set -x PATH /Users/ptolemy/.rbenv/shims $PATH

source /Users/ptolemy/Library/Preferences/org.dystroy.broot/launcher/fish/br

nvm use default

[ -s "/Users/ptolemy/.jabba/jabba.fish" ]; and source "/Users/ptolemy/.jabba/jabba.fish"
set -g fish_user_paths "/usr/local/opt/openssl@1.1/bin" $fish_user_paths
